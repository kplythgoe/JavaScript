"use strict";

let secretNumber = Math.trunc(Math.random() * 20) + 1;
let score = Number(document.querySelector(".score").textContent);
let highScore = 0;

const displayMessage = function (message) {
  document.querySelector(".message").textContent = message;
};

const changeBackground = function (color) {
  document.querySelector("body").style.backgroundColor = color;
};

const numberDisplay = function (value) {
  document.querySelector(".number").textContent = value;
};

const scoreDisplay = function (value) {
  document.querySelector(".score").textContent = value;
};

document.querySelector(".check").addEventListener("click", function () {
  const guess = Number(document.querySelector(".guess").value);

  // When there is no input
  if (!guess) {
    displayMessage("No Number!");
  }

  // When player wins
  else if (guess === secretNumber) {
    numberDisplay(secretNumber);
    displayMessage("Correct Number!");
    changeBackground("#60b346");
    document.querySelector(".number").style.width = "30rem";

    if (score > highScore) {
      highScore = score;
      document.querySelector(".highscore").textContent = highScore;
    }
  }

  // When guess is wrong
  else if (guess !== secretNumber) {
    changeBackground("red");
    setTimeout(() => {
      changeBackground("#222");
    }, 200);
    if (score > 1) {
      displayMessage(guess > secretNumber ? "Too High!" : "Too Low!");
      score--;
      scoreDisplay(score);
    } else {
      displayMessage("You lost the game.");
      scoreDisplay(0);
    }
  }
});

document.querySelector(".again").addEventListener("click", function () {
  changeBackground("#222");
  displayMessage("Start guessing...");
  score = 20;
  scoreDisplay(score);
  secretNumber = Math.trunc(Math.random() * 20) + 1;
  numberDisplay("?");
  document.querySelector(".number").style.width = "15rem";
  document.querySelector(".guess").value = "";
});
