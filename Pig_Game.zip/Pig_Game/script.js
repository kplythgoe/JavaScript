'use strict';

// Overall Scores
const score0El = document.getElementById('score--0');
const score1El = document.getElementById('score--1');

// Round Scores
let totalScores = [0, 0];
const current0 = document.getElementById('current--0');
const current1 = document.getElementById('current--1');
let currentScore = 0;
// Dice
let dice = document.querySelector('.dice');

// Event Listeners
const newBtn = document.querySelector('.btn--new');
const rollBtn = document.querySelector('.btn--roll');
const holdBtn = document.querySelector('.btn--hold');

// Active Player
let activePlayer = 0;
const player0 = document.querySelector('.player--0');
const player1 = document.querySelector('.player--1');

// Player Turns
score0El.textContent = 0;
score1El.textContent = 0;
dice.classList.add('hidden');

// Rolling dice functionality
rollBtn.addEventListener('click', function () {
  // 1. Generate random dice roll
  let diceRoll = Math.trunc(Math.random() * 6) + 1;
  // 2. Display dice
  dice.classList.remove('hidden');
  dice.src = `dice-${diceRoll}.png`;
  // 3. Check for rolled 1: if true, switch to next player
  if (diceRoll != 1) {
    currentScore += diceRoll;
    document.getElementById(`current--${activePlayer}`).textContent =
      currentScore;
  } else {
    currentScore = 0;
    document.getElementById(`current--${activePlayer}`).textContent =
      currentScore;
    activePlayer = activePlayer === 0 ? 1 : 0;
    player0.classList.toggle('player--active');
    player1.classList.toggle('player--active');
  }
});

holdBtn.addEventListener('click', function () {
  totalScores[activePlayer] += currentScore;
  document.getElementById(`score--${activePlayer}`).textContent =
    totalScores[activePlayer];

  if (totalScores[activePlayer] >= 100) {
    if (activePlayer == 0) {
      document.getElementById(`name--${activePlayer}`).textContent = `WINNER!`;
      document.getElementById(`name--1`).textContent = `LOSER!`;
    } else {
      document.getElementById(`name--0`).textContent = `LOSER!`;
      document.getElementById(`name--1`).textContent = `WINNER!`;
    }

    player0.classList.remove('player--active');
    player1.classList.remove('player--active');
    dice.classList.add('hidden');
    rollBtn.disabled = true;
    holdBtn.disabled = true;
  }

  currentScore = 0;
  document.getElementById(`current--${activePlayer}`).textContent =
    currentScore;
  activePlayer = activePlayer === 0 ? 1 : 0;
  player0.classList.toggle('player--active');
  player1.classList.toggle('player--active');
});

newBtn.addEventListener('click', function () {
  totalScores[0] = 0;
  totalScores[1] = 0;
  currentScore = 0;
  current0.textContent = currentScore;
  current1.textContent = currentScore;
  score0El.textContent = currentScore;
  score1El.textContent = currentScore;
  rollBtn.disabled = false;
  holdBtn.disabled = false;
  player1.classList.remove('player--active');
  dice.classList.remove('hidden');
});
